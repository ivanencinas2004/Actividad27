#creamos la clase Alumno
class Alumno():
    #realizamos un construtor al que le aplicamos los atributos
    def __init__(self,id, nombre, email):
        self.id=id
        self.nombre=nombre
        self.email=email
    #creamos funcion para hacer la ficha del alumno
    def fichaAlumno(self):
        print(f'nombre-{self.nombre} email-{self.email}')

#guardamos los datos de los alumnos
alumno1=Alumno(1, 'Jose','Jose@gmail.com')
alumno2=Alumno(2, 'Juan','Juan@gmail.com')  

alumno1.fichaAlumno()
alumno2.fichaAlumno() 
