#creamos una clase llamada curso
class Cursos():
    #creamos un constructor y le aplicamos unos atributos
    def __init__(self,id,nombre, creditos, añosdeestudio):
        self.id=id
        self.nombre=nombre
        self.creditos=creditos
        self.añosdeestudio=añosdeestudio
    #creamos la funcion en la que mos da la informacion de la ficha del curso (instanciamos)
    def fichaCurso(self):
        print(f'{self.nombre}-{self.creditos}-{self.añosdeestudio}')     

#guardamos los datos del curso
curso1=Cursos(1,'Grado',30,2)
curso2=Cursos(2,'Carrera',30,4)
curso1.fichaCurso()
curso2.fichaCurso()


                    
    







