from curso import Cursos
from alumno import Alumno


#creamos la clase matricula
class Matricula():
    #funcion constructor con sus atributos
    def __init__(self,idmatricula, fechamatricula, idalumno, idcurso):
        self.idmatricula=idmatricula
        self.fechamatricula=fechamatricula
        self.idalumno=idalumno
        self.idcurso=idcurso
    
    def infoMatricula(self):
        print(f'el alumno {self.idalumno}, se matricula en el curso {self.idcurso}  en la fecha {self.fechamatricula}')



alumno1=Alumno(1,'Jose','Jose@gmail.com') 
curso1=Cursos(1,'Grado',30,2)
alumno2=Alumno(2,'Juan','Juan@gmail.com')  
curso2=Cursos(2,'Carrera',30,4)
alumno=Matricula(1, '03/02/2021', alumno1.nombre, curso1.nombre )
alumno3=Matricula(2, '11/01/2022', alumno2.nombre, curso1.nombre)
alumno4=Matricula(2, '11/10/2022', alumno2.nombre, curso2.nombre)
alumno.infoMatricula()
alumno3.infoMatricula()
alumno4.infoMatricula()
        